﻿import os, pickle
class Student:
    name=''
    level=1
    technique = 0
    success_level = 0
    health_level=100
    money_count=0
    study_count =0
    knolidge_level = 0
#Уровень знаний. Он будет измеряться в процентах. Процент знаний - это прогресс знаний до следующего уровня.
    rehers_count=0
#rehers count это количество репитиций. От репитиций техника повышается.
    rest_count =0
    tired_level = 0
#Уровень усталости измеряется в процентах от 0 до 100.
    student_study ='Музыкальная школа'

    def __init__(self, name):
        self.name=name

    def student_preferences(self):
        print('Ваш уровень', student.level)
        print('Ваш уровень знаний', student.knolidge_level)
        print('Ваша техника равна', student.technique)
        print('Вы устали на', student.tired_level, 'процентов')

    def set_technique_level(self, technique):
        self.technique = self.technique + technique
        if self.technique >= 100:
            self.technique = 100

    def set_tired_level(self, tired_level):
        self.tired_level = self.tired_level + tired_level
        if self.tired_level >= 100:
            self.tired_level = 100

    def set_knolidge_level(self, knolidge_level):
        self.knolidge_level = self_knolidge_level + knolidge_level
        if knolidge_level >= 100:
            self.knolidge_level = 100

    def study_rehers(self):
        self.rehers_count = self.rehers_count + 1
        if self.tired_level == 0:
            self.set_technique_level(10)
            self.set_tired_level(5)
        elif self.tired_level == 100:
            self.set_technique_level(-1)
        else:
              self.set_technique_level(10 * (100 - self.tired_level) / 100)

    def study_knolidge(self):
        self.study_count = self.study_count + 1
        self.set_tired_level(5)
        if self.tired_level == 0:
             self.set_knolidge_level(10)
        elif self.tired_level == 100:
            self.set_knolidge_level(-1)
        else:
            self.set_knolidge_level(10 * (100 - self.tired_level) / 100)

    def take_rest(self):
        self.rest_count=self.rest_count + 1
        if self.tired_level >= 10:
            self.tired_level = self.tired_level - 10
        else:
            self.tired_level=0

class level:
    tired_rate = 1

print('Добро пожаловать! Выберите пункт меню:')
print('Нажмите 1, чтобы начать новую игру')
print('Нажмите 2, чтобы продолжить ранее начатую игру')
print('Нажмите 4, чтобы выйти')
menu_item =0
submenu_item = 0
while menu_item != 4:
    os.system('cls')
    print('Нажмите 1, чтобы начать новую игру')
    print('Нажмите 2, чтобы продолжить ранее начатую игру')
    print('Нажмите 4, чтобы выйти')
    print('Сделайте ваш выбор')
    menu_item=int(input())
    if menu_item==1:
        print('Начинаем новую игру!')
        print('Напишите, как вас зовут?')
        stu_name =input()
        student =Student(stu_name)
        print('Вы', student.name)
        print('На данный момент вы учитесь в', student.student_study)
        student.student_preferences()
        print('Нажмите 1, чтобы пойти учиться')
        print('Нажмите 2, чтобы пойти порепетировать')
        print('Нажмите 3, чтобы отдохнуть')
        while submenu_item != 4:
            submenu_item=int(input())
            if submenu_item==1:
                student.study_knolidge()
                student.student_preferences()
                if student.study_count >=5:
                    print('Вы так много трудитесь сегодня. Возможно, Вы немного устали. Отдохните немного!')
            if submenu_item == 2:
                student.study_rehers()
                print('Молодец!')
                student.student_preferences()
            if submenu_item == 3:
                student.take_rest()
                print('Вы немного отдохнули')
                student.student_preferences()
        output = open('data.pkl', 'wb')
        pickle.dump(student, output, 2)
        output.close()
        os.system('pause')
    if menu_item==2:
        print('Продолжаем!')
        input = open('data.pkl', 'rb')
        student = pickle.load(input)
        input.close()
        print(student.name)
        print('Ваш уровень', student.level)
        print('Ваша техника равна', student.technique)
        print('Ваш уровень успеваемости', student.success_level)
        print('На данный момент вы учитесь в', student.student_study)

        os.system('pause')